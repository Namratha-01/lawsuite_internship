﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DBProject.DAL;
using System.Data;



namespace DBProject
{
    public partial class treatmentHistory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TreatmentHistory(sender, e);
        }


        //-----------------------Function1--------------------------//

        protected void TreatmentHistory(object sender, EventArgs e)
        {
            myDAL objmyDAl = new myDAL();

            DataTable DT = new DataTable();


            int id = (int)Session["idoriginal"];


            int status = objmyDAl.gettreatmentHistory(id, ref DT);


            if (status == -1)
            {
                THistory.Text = "There was some error in retrieving the client's consultation History.";
            }

            else if (status == 0)
            {
                THistory.Text = "There is currently no consultation history of yours.";
            }

            else
            {
                THistory.Text = "History of " + status + " consultation is found: ";
                THistoryGrid.DataSource = DT;
                THistoryGrid.DataBind();
            }

            return;
        }
        

        //-----------------------Add a new function here------------------//




    }
}