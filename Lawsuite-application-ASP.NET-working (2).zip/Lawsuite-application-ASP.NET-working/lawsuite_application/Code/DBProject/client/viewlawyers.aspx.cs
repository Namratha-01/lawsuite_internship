﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DBProject.DAL;
using System.Data;


namespace DBProject
{
    public partial class Viewlawyers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["dID"] = "";
            deptlawyerInfo(sender, e);
        }

        //---------------Function Called whenever a lawyer is selected from the Grid View----//
        protected void TlawyerGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {
                Int16 num = Convert.ToInt16(e.CommandArgument);

                string dID = TlawyerGrid.Rows[num].Cells[2].Text;
  
                Session["dID"] = dID;

                Response.BufferOutput = true;
                Response.Redirect("lawyerProfile.aspx");

                return;
            }
        }



        //-----------------------Function1--------------------------//

        protected void deptlawyerInfo(object sender, EventArgs e)
        {
            myDAL objmyDAl = new myDAL();

            DataTable DT = new DataTable();

            string deptName = (string) Session["deptOriginal"];

            int status = objmyDAl.getDeptlawyerInfo(deptName, ref DT);


            if (status == -1)
            {
                Tlawyer.Text = "There was some error in retrieving the lawyer's Information.";
            }

            else
            {
                Tlawyer.Text = "Following are our Specialized lawyers of " + Session["deptOriginal"] + " Department:";
                TlawyerGrid.DataSource = DT;
                TlawyerGrid.DataBind();
            }

            return;
        }


        //-----------------------Add a new function here------------------//
    }
}