GO
create database DBProject

GO
use DBProject

go



/*
drop table Appointment
drop table OtherStaff
drop table client
drop table LoginTable
drop table lawyer
drop table Department
*/

--------------------------------------------------------
-------------------Creating Tables----------------------

--Type: 1 -- client
--Type: 2 -- lawyer
--Type: 3 -- Admin

--Status of lawyer
--  1 -- Present
--  0 -- Left

--Status of Bill
--Paid
--Unpaid

--Status of Appointment
--1-- Approved
--2-- Pending
--3-- Completed
--4-- Rejected

--lawyerNotification
--1--Seen	(Dekh Lya)
--2--Unseen	(Nahi Dekha)

--clientNotification
--1--Seen	(Dekh Lya)
--2--Unseen	(Nahi Dekha)

--FeedbackStatus
--1--Given	
--2--Pending	

--------------------------------------------------------


create table LoginTable
(
	LoginID int identity(1,1) primary key,
	Password varchar(20) not null,
	Email varchar(30) not null unique,
	Type int not null,
)



create table client
(
	clientID int primary key,
	Name varchar(30) not null,
	Phone char(11),
	Address varchar(40),
	BirthDate Date not null,
	Gender char(1) not null

	foreign key(clientID) references LoginTable(LoginID)
)



create table Department
(
	DeptNo int primary key,
	DeptName varchar(30) not null unique,
	Description varchar(1000)
)




create table lawyer
(
	lawyerID int primary key,
	Name varchar(30) not null,
	Phone char(11),
	Address varchar(40),
	BirthDate Date not null,
	Gender char(1) not null,

	DeptNo int not null,
	Charges_Per_Visit float not null,
	MonthlySalary float,
	ReputeIndex float,
	clients_Treated int DEFAULT 0 not null,

	Qualification varchar(100) not null,
	Specialization varchar(100),
	Work_Experience int,

	status int not null   --(Present = 1 or Left = 0)

	foreign key (DeptNo) references Department(DeptNo)
)


create table OtherStaff
(
	StaffID int identity(1,1) primary key,
	Name varchar(30) not null,
	Phone char(11),
	Address varchar(30),
	Designation varchar(15) not null,
	Gender char(1) not null,
	BirthDate Date,
	Highest_Qualification varchar(50),
	Salary float
)


create table Appointment
(
	AppointID int identity(1,1) primary key,
	lawyerID int,
	clientID int,
	Date Datetime,
	Appointment_Status int,

	Bill_Amount float,
	Bill_Status varchar(10),

	lawyerNotification int,
	clientNotification int,
	FeedbackStatus int,


	Disease varchar(100),
	Progress varchar(100),
	Prescription varchar(100)

	foreign key (lawyerID) references lawyer(lawyerID) on delete set null,
	foreign key (clientID) references client(clientID)
)

