

USE DBProject
GO


---------------------------------------------------------------------------------
--								STORED PROCEDURES							   --
---------------------------------------------------------------------------------



----------------------------(1)-------------------------------

---------------------Returns the Pending Appointments of Today------------ 
create PROCEDURE PENDING_APPOINTMENTS2
@lawyer_ID INT
AS
BEGIN
	SELECT A.AppointID, P.Name as [client's Name], A.[Date],Appointment_Status FROM Appointment A
	JOIN client P ON A.clientID = P.clientID
	WHERE A.lawyerID = @lawyer_ID AND A.Appointment_Status = 2 and DATEDIFF(DAY, A.Date, GETDATE()) = 0
END




----------------------------(2)-------------------------------
GO
-------------Approves a Particular Appointment----------------
create PROCEDURE APPROVE_APPOINTMENT
@APPOINT_ID INT
AS
BEGIN
	UPDATE Appointment
	SET Appointment_Status = 1, clientNotification = 2
	WHERE AppointID = @APPOINT_ID
END




----------------------------(3)-------------------------------

-------------Returns the Approved Appointments of Today----------------
GO
create PROCEDURE TODAYS_APPOINTMENTS
@DOC_ID INT
AS
BEGIN
	SELECT A.AppointID, P.Name as [client's Name], A.[Date], isnull( convert( varchar(2),Bill_Amount) ,  'NA') as [Bill Amount], isnull( convert( varchar(2),Bill_Status),  'NA')  as [Bill Status] , isnull( convert( varchar(2),Disease) ,  'NA') as [Disease], isnull( convert( varchar(2),Progress) ,  'NA') as [Progress], isnull( convert( varchar(2),Prescription) ,  'NA') as [Prescription], Appointment_Status  FROM Appointment A
	JOIN client P ON A.clientID = P.clientID
	WHERE A.lawyerID = @DOC_ID AND A.Appointment_Status = 1 and DATEDIFF(DAY, A.Date, GETDATE()) = 0
END




----------------------------(4)-------------------------------

-------------Generates the Bill----------------
GO
create procedure generate_bill
@did int
as 
begin
	select Charges_per_Visit as [Charges] from lawyer 
	where lawyerID=@did
end




----------------------------(5)-------------------------------

-------------When the Appointment is Completed and Bill is not Paid----------------

GO
create procedure finishedUnpaid
@docId int,
@appointid  int 
as 
begin
	update Appointment
	set Bill_Status='Unpaid',Appointment_Status=3,clientNotification=2, Bill_Amount = (select Charges_Per_Visit from lawyer where lawyerID=@docId),FeedbackStatus = 2
	where AppointID=@appointid

	update lawyer
	set clients_Treated = clients_Treated + 1
	where lawyerID = @docId
end



----------------------------(6)-------------------------------

-------------When the Appointment is Completed and Bill is Paid----------------


GO
create procedure finishedPaid
@docId int,
@appointid  int
as 
begin
	update Appointment
	set Bill_Status='paid',Appointment_Status=3,clientNotification=2,Bill_Amount=(select Charges_Per_Visit from lawyer where lawyerID=@docId),FeedbackStatus = 2
	where AppointID=@appointid

		update lawyer
	set clients_Treated = clients_Treated + 1
	where lawyerID = @docId

end




----------------------------(7)-------------------------------

-------------When an Appointment is Rejected----------------

GO
create procedure delete_APPOINTMENT
@APPOINT_ID int
as 
begin
	update Appointment
	set Appointment_Status=4, clientNotification = 2
	where AppointID=@APPOINT_ID
end





----------------------------(8)-------------------------------

------------Display lawyer's Info----------------

GO
create procedure lawyer_Information_By_ID1
@Id int
as 
begin 
	select * from lawyer where lawyerid=@id
end




----------------------------(9)-------------------------------

------------Update the Prescription when the Appointment is Completed----------------

GO
create procedure UpdatePrescription
@docId int ,
@appointid int,
@Disease varchar(30),
@Progress varchar(50),
@Prescription varchar(60)
as 

begin
	update Appointment 
	set Disease=@disease,Progress=@progress,Prescription=@prescription,Appointment_Status=3,clientNotification=2,FeedbackStatus = 2
	where Appointid=@appointid
end




----------------------------(10)-------------------------------

------------To get the information about an appointment----------------
GO
create PROCEDURE get_appointment
@APPOINT_ID INT
AS
BEGIN
	select Appointid,Date,Appointment_Status,Bill_Amount,Bill_Status,Disease,Progress,Prescription  from Appointment
	WHERE AppointID = @APPOINT_ID
END




----------------------------(11)-------------------------------
GO
create PROCEDURE retrievePHistory
@dID INT
AS
BEGIN
		select P.Name as [Name], Disease, Progress, Prescription
		from Appointment A join client P on A.clientID = P.clientID
		where lawyerID = @dId and Appointment_Status = 3
END


